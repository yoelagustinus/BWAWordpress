This issue might be with the theme which you are using

Please do make sure that your theme has `woocommerce_shop_loop_item_title` AND `woocommerce_after_shop_loop_item_title` filter in the below files

```
1. your-theme/woocommerce/content-product.php
```