This issue might be with the theme which you are using

Please do make sure that your theme has `woocommerce_single_product_summary` filter in the below files

```
1. your-theme/woocommerce/content-product.php
```