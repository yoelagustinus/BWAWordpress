This issue might be with the theme which you are using

Please do make sure that your theme has `woocommerce_cart_item_name` filter in the below files
```
1. your-theme/woocommerce/cart/cart.php
2. your-theme/woocommerce/cart/mini-cart.php
3. your-theme/woocommerce/cart/review-order.php
```