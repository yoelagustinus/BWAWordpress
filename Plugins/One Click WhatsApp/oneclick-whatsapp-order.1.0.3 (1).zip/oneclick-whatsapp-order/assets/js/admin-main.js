// Shortcode Benerator
function generateWAshortcode(form) {
	var Vselected_wa_number = document.getElementById("selected_wa_number").value
	var VWAbuttonText = document.getElementById("WAbuttonText").value  
	var VWAcustomMessage = document.getElementById("WAcustomMessage").value
	var VWAnewTab = document.getElementById("WAnewTab").value
	var generatedWAbuttonData = '[waorder phone="'+Vselected_wa_number+'" button="'+VWAbuttonText+'" message="'+VWAcustomMessage+'" target="'+VWAnewTab+'"]';
	document.getElementById("generatedShortcode").innerHTML = generatedWAbuttonData;
}