<?php

// Hide WhatsApp button on selected pages
add_action('wp_head', 'wa_order_display_options');
function wa_order_display_options(){
// Hide button on shop loop - desktop
if ( get_option(sanitize_text_field('wa_order_display_option_shop_loop_hide_desktop')) === 'yes' ) {
		?>
		<style>
			@media only screen and (min-width: 768px) {
			.wa-shop-button{display:none!important;}
			}
		</style>
	    <?php
	}
// Hide button on shop loop - mobile
if ( get_option(sanitize_text_field('wa_order_display_option_shop_loop_hide_mobile')) === 'yes' ) {
		?>
		<style>
			@media only screen and (max-width: 767px) {
			.wa-shop-button{display:none!important;}
			}
		</style>
	    <?php
	}
// Hide button on cart page - desktop
if ( get_option(sanitize_text_field('wa_order_display_option_cart_hide_desktop')) === 'yes' ) {
		?>
		<style>
			@media only screen and (min-width: 767px) {
			.wc-proceed-to-checkout .wa-order-checkout{display:none!important;}
			}
		</style>
	    <?php
	}
// Hide button on cart page - mobile
if ( get_option(sanitize_text_field('wa_order_display_option_cart_hide_mobile')) === 'yes' ) {
		?>
		<style>
			@media only screen and (max-width: 767px) {
			.wc-proceed-to-checkout .wa-order-checkout{display:none!important;}
			}
		</style>
	    <?php
	}
// Hide button on thank you page - desktop
if ( get_option(sanitize_text_field('wa_order_display_option_checkout_hide_desktop')) === 'yes' ) {
		?>
		<style>
			@media only screen and (min-width: 767px) {
			a.wa-order-thankyou{display:none!important;}
			}
		</style>
	    <?php
	}
// Hide button on thank you page - mobile
if ( get_option(sanitize_text_field('wa_order_display_option_checkout_hide_mobile')) === 'yes' ) {
		?>
		<style>
			@media only screen and (max-width: 767px) {
			a.wa-order-thankyou{display:none!important;}
			}
		</style>
	    <?php
	}
}

// Hide Product Quantity
function wa_order_remove_quantity( $return, $product ) {
	if ( get_option(sanitize_text_field('wa_order_option_remove_quantity')) )
    return true;
}
add_filter( 'woocommerce_is_sold_individually', 'wa_order_remove_quantity', 10, 2 );