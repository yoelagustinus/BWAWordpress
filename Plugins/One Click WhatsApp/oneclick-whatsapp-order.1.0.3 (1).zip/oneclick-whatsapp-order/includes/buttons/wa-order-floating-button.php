<?php

// Display Floating Button
function display_floating_button() {
	global $wp;
	$floating = get_option(sanitize_text_field('wa_order_floating_button'));
	if ( $floating === 'yes' ) {
	$floating_position = get_option(sanitize_text_field('wa_order_floating_button_position'));
	$custom_message = get_option(sanitize_text_field('wa_order_floating_message'));
	$floating_target = get_option(sanitize_text_field('wa_order_floating_target'));
	$button_text = get_option(sanitize_text_field('wa_order_option_text_button'));
	$target = get_option(sanitize_text_field('wa_order_option_target'));
	global $post;
	// WA Number from Setting
	$wanumberpage = get_option( 'wa_order_selected_wa_number_floating' );
	$postid = get_page_by_path( $wanumberpage, '', 'wa-order-numbers');
	if( empty( $postid) ) {
	    $pid = 0;
	} else {
	    $pid = $postid->ID;
	}
	$phonenumb = get_post_meta($pid, 'wa_order_phone_number_input', true);
	
	$tooltip_enable = get_option(sanitize_text_field('wa_order_floating_tooltip_enable'));
	$floating_mobile = get_option(sanitize_text_field('wa_order_floating_hide_mobile'));
	$floating_desktop = get_option(sanitize_text_field('wa_order_floating_hide_desktop'));

	// Include source page URL
	$include_source = get_option(sanitize_text_field('wa_order_floating_source_url'));
	$src_label = get_option(sanitize_text_field('wa_order_floating_source_url_label'));
	if ($src_label== '') $source_label= "From URL:";
		else $source_label= "$src_label";
	if ( $include_source === 'yes') {
		$source_url = home_url(add_query_arg(array(), $wp->request));
		$floating_message = urlencode(" ".$custom_message."\r\n\r\n*".$source_label."* ".$source_url." ");
	} else {
		$floating_message = $custom_message;
	}

	//Check if it's mobile or desktop
	$wa_base = 'web';
	if (wp_is_mobile()) {
	    $wa_base = 'api';
	}
	$floating_link = "https://$wa_base.whatsapp.com/send?phone=$phonenumb&text=$floating_message";

	    if ( $floating_position === 'left' ) { ?>
			<a id="sendbtn" class="floating_button" href="<?php echo $floating_link ?>" role="button" target="<?php echo $floating_target ?>">
			</a>

				<style>
					.floating_button {
						left: 20px;
					}
					@media only screen and (min-device-width: 320px) and (max-device-width: 480px) {
					    .floating_button {
					        left: 10px!important;
					    }
					}
				</style>

	 	<?php  } elseif ( $floating_position === 'right' ) { ?>
		<a id="sendbtn" class="floating_button" href="<?php echo $floating_link ?>" role="button" target="<?php echo $floating_target ?>">
		</a>
			<style>
				.floating_button {
					right: 20px;
				}
				@media only screen and (min-device-width: 320px) and (max-device-width: 480px) {
				    .floating_button {
				        right: 10px!important;
				    }
				}
			</style>			
     <?php
    }
}
}
add_filter('wp_head', 'display_floating_button');

// Display Floating Button with Tooltip
function display_floating_tooltip() {
	global $wp;
	$floating = get_option(sanitize_text_field('wa_order_floating_button'));
	$floating_position = get_option(sanitize_text_field('wa_order_floating_button_position'));
	$custom_message = get_option(sanitize_text_field('wa_order_floating_message'));
	$floating_target = get_option(sanitize_text_field('wa_order_floating_target'));
	$button_text = get_option(sanitize_text_field('wa_order_option_text_button'));
	$target = get_option(sanitize_text_field('wa_order_option_target'));
	global $post;
	// WA Number from Setting
	$wanumberpage = get_option( 'wa_order_selected_wa_number_floating' );
	$postid = get_page_by_path( $wanumberpage, '', 'wa-order-numbers');
	if( empty( $postid) ) {
	    $pid = 0;
	} else {
	    $pid = $postid->ID;
	}
	$phonenumb = get_post_meta($pid, 'wa_order_phone_number_input', true);

	$tooltip_enable = get_option(sanitize_text_field('wa_order_floating_tooltip_enable'));
	$tool_tip = get_option(sanitize_text_field('wa_order_floating_tooltip'));
	if ($tool_tip== '') $tooltip = "Let's Chat";
	else $tooltip= "$tool_tip";

	$floating_mobile = get_option(sanitize_text_field('wa_order_floating_hide_mobile'));
	$floating_desktop = get_option(sanitize_text_field('wa_order_floating_hide_desktop'));

	// Include source page URL
	$include_source = get_option(sanitize_text_field('wa_order_floating_source_url'));
	$src_label = get_option(sanitize_text_field('wa_order_floating_source_url_label'));
	if ($src_label== '') $source_label= "From URL:";
	else $source_label= "$src_label";

	if ( $include_source === 'yes') {
		$source_url = home_url(add_query_arg(array(), $wp->request));
		$floating_message = urlencode(" ".$custom_message."\r\n\r\n*".$source_label."* ".$source_url." ");
	} else {
		$floating_message = $custom_message;
	}

	//Check if it's mobile or desktop
	$wa_base = 'web';
	if (wp_is_mobile()) {
	    $wa_base = 'api';
	}
	$floating_link = "https://$wa_base.whatsapp.com/send?phone=$phonenumb&text=$floating_message";
		if ( $floating === 'yes' && $floating_position === 'left' && $tooltip_enable === 'yes' ) { ?>
			<a id="sendbtn" href="<?php echo $floating_link ?>" role="button" target="<?php echo $floating_target ?>" class="floating_button">
			    <div class="label-container">
			    	<div class="label-text"><?php echo $tooltip ?></div>
			    </div>
			</a>
			<style>
			.floating_button {
				left: 20px;
			}
				.label-container {
  					left: 85px;
				}		
			</style>
		<?php  } elseif ( $floating === 'yes' && $floating_position === 'right' && $tooltip_enable === 'yes' ) { ?>
			<a id="sendbtn" href="<?php echo $floating_link ?>" role="button" target="<?php echo $floating_target ?>" class="floating_button">
			    <div class="label-container">
			    	<div class="label-text"><?php echo $tooltip ?></div>
			    </div>
			</a>
			<style>
				.floating_button {
					right: 20px;
				}
				.label-container {
  					right: 85px;
				}				
			</style>	
     <?php
    }
}
add_filter('wp_head', 'display_floating_tooltip');

// Hide Floating Button on Mobile
function hide_floating_button_mobile() {
	$floating_mobile = get_option(sanitize_text_field('wa_order_floating_hide_mobile'));
	if ( $floating_mobile === 'yes' ) { ?>
			<style>
			@media only screen and (min-device-width: 320px) and (max-device-width: 480px) {
				.floating_button {
					display: none !important;
				}
			}		
			</style>
     <?php
    }     
}
add_filter('wp_head', 'hide_floating_button_mobile');

// Hide Floating Button on Desktop
function hide_floating_button_desktop() {
	$floating_desktop = get_option(sanitize_text_field('wa_order_floating_hide_desktop'));
	if ( $floating_desktop === 'yes' ) { ?>
			<style>
			@media (min-width: 601px) {
				.floating_button {
					display: none !important;
				}
			}		
			</style>
     <?php
    }     
}
add_filter('wp_head', 'hide_floating_button_desktop');